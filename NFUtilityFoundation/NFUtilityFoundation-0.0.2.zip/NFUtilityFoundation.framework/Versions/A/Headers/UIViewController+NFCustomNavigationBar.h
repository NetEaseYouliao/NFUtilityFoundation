//
//  UIViewController+NFCustomNavigationBar.h
//  NewsFeedsDemo
//
//  Created by shoulei ma on 2017/7/1.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (NFCustomNavigationBar)

/**
 导航栏底部的进度条
 
 @param progress 进度
 */
- (void)nf_setProgress:(CGFloat)progress;

/**
 默认导航栏样式
 
 @note 需要根据视觉要求，自定义本方法实现中的样式定制
 */
- (void)nf_applyDefaultNavigationBarStyle;

/**
 默认导航栏样式
 
 @note 需要根据视觉要求，自定义本方法实现中的样式定制
 */
- (void)nf_applyDetailNavigationBarStyle;

/**
 透明导航栏样式，白色状态栏
 
 @note 需要根据视觉要求，自定义本方法实现中的样式定制
 */
- (void)nf_applyTransparentNavigationBarWhiteStatus;

/**
 透明导航栏，黑色状态栏
 
 @note 需要根据视觉要求，自定义本方法实现中的样式定制
 */
- (void)nf_applyTransparentNavigationBarDarkStatus;

- (void)nf_applyPureBlackNavigationBarStyle;

/**
 添加左侧返回键
 
 @return 添加的 button，可以在此返回的 button 上定制样式和添加事件
 
 @note 需要根据视觉要求，自定义本方法实现中的样式定制
 */
- (UIButton *)nf_addNavigationLeftBackItem;

/**
 添加右侧键
 
 @return 添加的 button，可以在此返回的 button 上定制样式和添加事件
 
 @note 需要根据视觉要求，自定义本方法实现中的样式定制
 */
- (UIButton *)nf_addNavigationRightItem;

/**
 添加和删除自定义导航栏视图
 */
- (void)nf_addCustomNavigationBar;
- (void)nf_removeCustomNavigationBar;

/**
 更新自定义导航栏标题文案

 @param title 标题文案
 */
- (void)nf_updateCustomNavTitle:(NSString *)title;

/**
 更新自定义导航栏左侧元素图片

 @param normalImage 默认图片
 @param highlightedImage 高亮图片
 */
- (void)nf_updateCustomLeftItemWithNormalImage:(UIImage *)normalImage highlightedImage:(UIImage *)highlightedImage;

/**
 更新自定义导航栏右侧元素图片

 @param normalImage 默认图片
 @param highlightedImage 高亮图片
 */
- (void)nf_updateCustomRightItemWithNormalImage:(UIImage *)normalImage highlightedImage:(UIImage *)highlightedImage;

/**
 显示和隐藏右侧元素
 */
- (void)nf_showCustomRightItem;
- (void)nf_hideCustomRightItem;

@end
