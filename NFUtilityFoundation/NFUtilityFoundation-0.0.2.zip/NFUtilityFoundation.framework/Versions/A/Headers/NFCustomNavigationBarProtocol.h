//
//  NFCustomNavigationBarProtocol.h
//  Pods
//
//  Created by CaiSanze on 2018/4/16.
//

#ifndef NFCustomNavigationBarProtocol_h
#define NFCustomNavigationBarProtocol_h

@protocol NFCustomNavigationBarProtocol <NSObject>

@optional
- (void)nf_customNavigationBarLeftItemClicked;
- (void)nf_customNavigationBarRightItemClicked;

@end

#endif /* NFCustomNavigationBarProtocol_h */
