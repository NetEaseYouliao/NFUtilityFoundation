//
//  NFUIDefines.h
//  NewsFeedsUISDK
//
//  Created by shoulei ma on 2017/10/11.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import "UIColor+NFColor.h"

#ifndef NFUIDefines_h
#define NFUIDefines_h

//每页最大展示条数
#define MAX_PAGE_NEWS_NUM 200

/// 屏幕宽度
#define NF_SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
/// 屏幕高度
#define NF_SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height

#define NF_LINE_WIDTH (1 / [UIScreen mainScreen].scale)

#define NFStatusBarHeight   20.0f
#define NFNavigationHeight  44.0f

#define IS_IPHONE_X ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) && ([[UIScreen mainScreen] bounds].size.height == 812))
#define NFNavBarHeight (IS_IPHONE_X ? 88.0f : 64.0f)
#define NFNavBarPositionY (IS_IPHONE_X ? 44.0f : 20.0f)
#define NFScreenBottomMargin (IS_IPHONE_X ? 33.0f : 0.0f)
#define NFRGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]

#define NFMainColor                           [UIColor nf_colorWithRGBValue:0x0099fb]
#define NFChannelTextColor                    [UIColor nf_colorWithRGBValue:0x888888]
#define NFChannelHighLightColor               [UIColor nf_colorWithRGBValue:0x888888]
#define NFChannelSelectedColor                [UIColor nf_colorWithRGBValue:0x333333]
#define NFDefaltViewBackGroundColor           [UIColor nf_colorWithRGBValue:0xF1F1F1]
#define NFLoadingIndicateColor                [UIColor nf_colorWithRGBValue:0x666666]
#define NFNewsListTitleColor                  [UIColor nf_colorWithRGBValue:0x121212]
#define NFNewsListSrcColor                    [UIColor nf_colorWithRGBValue:0x9B9B9B]
#define NFNewsReadColor                       [UIColor nf_colorWithRGBValue:0x808080]
#define NFNaviBackgroundColor                 [UIColor nf_colorWithRGBValue:0x3B9BFD]
#define NFNaviTitleColor                      [UIColor whiteColor]
#define NFDefaltViewBackGroundColor           [UIColor nf_colorWithRGBValue:0xF1F1F1]

#define NFFont9                [UIFont systemFontOfSize:9]
#define NFFont10               [UIFont systemFontOfSize:10]
#define NFFont11               [UIFont systemFontOfSize:11]
#define NFFont12               [UIFont systemFontOfSize:12]
#define NFFont13               [UIFont systemFontOfSize:13]
#define NFFont14               [UIFont systemFontOfSize:14]
#define NFFont15               [UIFont systemFontOfSize:15]
#define NFFont16               [UIFont systemFontOfSize:16]
#define NFFont17               [UIFont systemFontOfSize:17]
#define NFFont18               [UIFont systemFontOfSize:18]
#define NFFont19               [UIFont systemFontOfSize:19]
#define NFFont21               [UIFont systemFontOfSize:21]
#define NFFont24               [UIFont systemFontOfSize:24]
#define NFFont25               [UIFont systemFontOfSize:25]

extern const CGFloat kMargin;

extern const CGFloat kSmallImageWitdth;
extern const CGFloat kSmallImageHeight;

extern const CGFloat kLargeImageWitdth;
extern const CGFloat kLargeImageHeight;

#endif
