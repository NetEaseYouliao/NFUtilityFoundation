//
//  UIColor+NFColor.h
//  NFUtilityFoundation
//
//  Created by Jingjq on 2018/4/25.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wauto-import"
#pragma GCC diagnostic ignored "-Wobjc-missing-property-synthesis"

#import <UIKit/UIKit.h>

@interface UIColor (NFColor)

- (void)getRGBAComponents:(CGFloat[4])rgba;

@property (nonatomic, readonly) CGFloat nf_red;
@property (nonatomic, readonly) CGFloat nf_green;
@property (nonatomic, readonly) CGFloat nf_blue;
@property (nonatomic, readonly) CGFloat nf_alpha;

+ (instancetype)nf_colorWithString:(NSString *)string;
+ (instancetype)nf_colorWithRGBValue:(uint32_t)rgb;
+ (instancetype)nf_colorWithRGBValue:(uint32_t)rgb alpha:(CGFloat)alpha;
+ (instancetype)nf_colorWithRGBAValue:(uint32_t)rgba;
- (instancetype)initWithNFString:(NSString *)string;
- (instancetype)initWithNFRGBValue:(uint32_t)rgb;
- (instancetype)initWithNFRGBAValue:(uint32_t)rgba;

- (uint32_t)nf_RGBValue;
- (uint32_t)nf_RGBAValue;
- (NSString *)nf_stringValue;

- (BOOL)nf_isMonochromeOrRGB;
- (BOOL)nf_isEquivalent:(id)object;
- (BOOL)nf_isEquivalentToColor:(UIColor *)color;

- (instancetype)nf_colorWithBrightness:(CGFloat)brightness;
- (instancetype)nf_colorBlendedWithColor:(UIColor *)color factor:(CGFloat)factor;

@end

#pragma GCC diagnostic pop
