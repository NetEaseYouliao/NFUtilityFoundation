//
//  UIView+NFFrame.h
//  NFUtilityFoundation
//
//  Created by hih-d-11371 on 2018/4/12.
//

#import <UIKit/UIKit.h>

@interface UIView (NFFrame)

@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;
@property (nonatomic, assign) CGSize  size;

@end
 
