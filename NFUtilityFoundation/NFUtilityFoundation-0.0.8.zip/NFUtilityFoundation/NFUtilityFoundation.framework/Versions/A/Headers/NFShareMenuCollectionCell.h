//
//  NFShareMenuCollectionCell.h
//  Pods
//
//  Created by Jingjq on 2018/4/12.
//

#import <UIKit/UIKit.h>
#import "NFShareActivity.h"

@interface NFShareMenuCollectionCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *iconImage;

@property (nonatomic, strong) UILabel *titleLabel;

- (void)configCellWithInfo:(NFShareActivity *)info;

@end
