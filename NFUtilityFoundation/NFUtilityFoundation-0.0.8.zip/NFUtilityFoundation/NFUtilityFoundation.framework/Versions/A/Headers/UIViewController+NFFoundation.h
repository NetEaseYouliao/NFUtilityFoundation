//
//  UIViewController+NFFoundation.h
//  Pods
//
//  Created by Jingjq on 2018/4/13.
//

#import <UIKit/UIKit.h>

@interface UIViewController (NFFoundation)

- (void)presentTransparentVC:(UIViewController *_Nonnull)viewControllerToPresent
                    animated:(BOOL)flag
                  completion:(void (^ _Nullable)(void))completion;

@end
