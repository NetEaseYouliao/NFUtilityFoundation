//
//  NFShareActivity.h
//  NewsFeedsHybridSDK-NFHybridBundle
//
//  Created by Jingjq on 2018/4/12.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, NFShareType) {
    //开始点，不做正式类型
    NFShareType_Begin = -1,
    //微信好友
    NFShareType_WeChatFriend = 0,
    //微信朋友圈
    NFShareType_WeChatTimeLine,
    //结束点，不做正式类型
    NFShareType_End,
};

@interface NFShareActivity : UIActivity

@property (nonatomic, assign) NFShareType shareType;

@property (nonatomic, copy) NSDictionary *shareMsgDic;

/**
 *  指定构造器
 *
 *  @param shareType 分享类型
 *
 *  @return NFShareActivity实例
 */
- (instancetype)initWithShareActivityType:(NFShareType)shareType;

/**
 *  常用的分享NFShareActivity集合
 *
 *  @param msg 分享内容
 *
 *  @return NFShareActivity集合
 */
+ (NSArray<NFShareActivity *> *)commonShareActivitiesWithMsg:(NSDictionary *)msg;
/**
 *  常用的分享NFShareActivity集合
 *
 *  @param msg          分享内容
 *  @param exceptTypes 需要排除的分享类型
 *
 *  @return NFShareActivity集合
 */
+ (NSArray<NFShareActivity *> *)commonShareActivitiesWithMsg:(NSDictionary *)msg exceptTypes:(NSArray<NSNumber *> *)exceptTypes;

@end
