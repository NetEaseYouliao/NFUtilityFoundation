//
//  NFActivityIndicator.h
//  NewsFeedsDemo
//
//  Created by shoulei ma on 2017/7/3.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFActivityIndicator : UIView

@property (nonatomic, strong) UIImageView *activitorImageView;

- (void)startAnimating;

- (void)stopAnimating;

@end
