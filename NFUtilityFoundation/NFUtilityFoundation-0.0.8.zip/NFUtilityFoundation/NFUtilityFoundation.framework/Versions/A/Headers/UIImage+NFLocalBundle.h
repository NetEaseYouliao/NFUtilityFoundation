//
//  UIImage+NFLocalBundle.h
//  NFUtilityFoundation
//
//  Created by Jingjq on 2018/4/26.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (NFLocalBundle)

+ (UIImage *)nf_imageNamed:(NSString *)imageName
                bundleName:(NSString *)bundleName;

+ (UIImage *)nf_imageNamed:(NSString *)imageName
                bundleName:(NSString *)bundleName
               bundleClass:(Class)aClass;

@end
