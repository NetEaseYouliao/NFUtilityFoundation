//
//  NSString+NFURLEncoding.h
//  NFUtilityFoundation
//
//  Created by Jingjq on 2018/4/26.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NFURLEncoding)

/*
 * 未对特殊字符!*'();:@&=+$,/?%#[]做Encoding。可对整个URL做Encoding
 */
- (NSString *)stringByURLEncoding;
/*
 * 对特殊字符!*'();:@&=+$,/?%#[]做Encoding。可用于对参数Encoding
 */
- (NSString *)stringByRemoveCharactersEncoding;

@end
