//
//  UIFont+NFFont.h
//  NFUtilityFoundation
//
//  Created by CaiSanze on 2018/5/8.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFont (NFFont)

+ (UIFont *)nf_regularFontWithSize:(CGFloat)size;
+ (UIFont *)nf_lightFontWithSize:(CGFloat)size;
+ (UIFont *)nf_mediumFontWithSize:(CGFloat)size;
+ (UIFont *)nf_semiblodFontWithSize:(CGFloat)size;
+ (UIFont *)nf_boldFontWithSize:(CGFloat)size;

@end
