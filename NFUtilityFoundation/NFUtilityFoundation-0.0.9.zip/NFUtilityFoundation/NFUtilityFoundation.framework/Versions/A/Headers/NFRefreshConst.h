//  代码地址: https://github.com/CoderNFLee/NFRefresh
//  代码地址: http://code4app.com/ios/%E5%BF%AB%E9%80%9F%E9%9B%86%E6%88%90%E4%B8%8B%E6%8B%89%E4%B8%8A%E6%8B%89%E5%88%B7%E6%96%B0/52326ce26803fabc46000000
#import <UIKit/UIKit.h>
#import <objc/message.h>

// 弱引用
#define NFWeakSelf __weak typeof(self) weakSelf = self;

// 日志输出
#ifdef DEBUG
#define NFRefreshLog(...) NSLog(__VA_ARGS__)
#else
#define NFRefreshLog(...)
#endif

// 过期提醒
#define NFRefreshDeprecated(instead) NS_DEPRECATED(2_0, 2_0, 2_0, 2_0, instead)

// 运行时objc_msgSend
#define NFRefreshMsgSend(...) ((void (*)(void *, SEL, UIView *))objc_msgSend)(__VA_ARGS__)
#define NFRefreshMsgTarget(target) (__bridge void *)(target)

// RGB颜色
#define NFRefreshColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]

// 文字颜色
#define NFRefreshLabelTextColor NFRefreshColor(90, 90, 90)

// 字体大小
#define NFRefreshLabelFont [UIFont boldSystemFontOfSize:14]

// 常量
UIKIT_EXTERN const CGFloat NFRefreshLabelLeftInset;
UIKIT_EXTERN const CGFloat NFRefreshHeaderHeight;
UIKIT_EXTERN const CGFloat NFRefreshFooterHeight;
UIKIT_EXTERN const CGFloat NFRefreshFastAnimationDuration;
UIKIT_EXTERN const CGFloat NFRefreshSlowAnimationDuration;

UIKIT_EXTERN NSString *const NFRefreshKeyPathContentOffset;
UIKIT_EXTERN NSString *const NFRefreshKeyPathContentSize;
UIKIT_EXTERN NSString *const NFRefreshKeyPathContentInset;
UIKIT_EXTERN NSString *const NFRefreshKeyPathPanState;

UIKIT_EXTERN NSString *const NFRefreshHeaderLastUpdatedTimeKey;

UIKIT_EXTERN NSString *const NFRefreshHeaderIdleText;
UIKIT_EXTERN NSString *const NFRefreshHeaderPullingText;
UIKIT_EXTERN NSString *const NFRefreshHeaderRefreshingText;

UIKIT_EXTERN NSString *const NFRefreshAutoFooterIdleText;
UIKIT_EXTERN NSString *const NFRefreshAutoFooterRefreshingText;
UIKIT_EXTERN NSString *const NFRefreshAutoFooterNoMoreDataText;

UIKIT_EXTERN NSString *const NFRefreshBackFooterIdleText;
UIKIT_EXTERN NSString *const NFRefreshBackFooterPullingText;
UIKIT_EXTERN NSString *const NFRefreshBackFooterRefreshingText;
UIKIT_EXTERN NSString *const NFRefreshBackFooterNoMoreDataText;

UIKIT_EXTERN NSString *const NFRefreshHeaderLastTimeText;
UIKIT_EXTERN NSString *const NFRefreshHeaderDateTodayText;
UIKIT_EXTERN NSString *const NFRefreshHeaderNoneLastDateText;

// 状态检查
#define NFRefreshCheckState \
NFRefreshState oldState = self.state; \
if (state == oldState) return; \
[super setState:state];
