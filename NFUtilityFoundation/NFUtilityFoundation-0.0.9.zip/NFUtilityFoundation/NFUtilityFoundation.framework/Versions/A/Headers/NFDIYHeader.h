//
//  MJDIYHeader.h
//  MJRefreshExample
//
//  Created by MJ Lee on 15/6/13.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "NFRefreshHeader.h"

@interface NFDIYHeader : NFRefreshHeader



#pragma mark - appearance
@property(nonatomic, copy)   NSString *pullingText UI_APPEARANCE_SELECTOR;
@property(nonatomic, copy)   NSString *releaseToRefreshText UI_APPEARANCE_SELECTOR;
@property(nonatomic, copy)   NSString *loadingText UI_APPEARANCE_SELECTOR;
@property(nonatomic, strong) UIColor *refreshTextColor UI_APPEARANCE_SELECTOR;

@end
