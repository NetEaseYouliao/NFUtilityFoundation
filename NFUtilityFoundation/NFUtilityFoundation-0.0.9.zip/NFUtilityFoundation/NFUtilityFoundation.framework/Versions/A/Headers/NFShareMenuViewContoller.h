//
//  NFShareMenuViewContoller.h
//  Pods
//
//  Created by Jingjq on 2018/4/13.
//

#import <UIKit/UIKit.h>

#import "NFShareActivity.h"

typedef void (^NFShareClickCallback)(NFShareActivity *activity);

@interface NFShareMenuViewContoller : UIViewController

@property (nonatomic, copy) NSArray<NFShareActivity *> *shareActivities;

@property (nonatomic, copy) NFShareClickCallback shareClickCallback;

@end
