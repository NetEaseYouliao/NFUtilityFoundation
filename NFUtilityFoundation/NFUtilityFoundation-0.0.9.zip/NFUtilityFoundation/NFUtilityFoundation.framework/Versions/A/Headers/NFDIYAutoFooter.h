//
//  MJDIYAutoFooter.h
//  MJRefreshExample
//
//  Created by MJ Lee on 15/6/13.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "NFRefreshAutoFooter.h"

@interface NFDIYAutoFooter : NFRefreshAutoFooter

#pragma mark - appearance
@property(nonatomic, copy)   NSString *loadMoreText UI_APPEARANCE_SELECTOR;
@property(nonatomic, strong) UIColor *loadMoreTextColor UI_APPEARANCE_SELECTOR;
@end
