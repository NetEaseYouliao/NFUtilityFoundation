//
//  UIView+NFFrame.h
//  NFUtilityFoundation
//
//  Created by hih-d-11371 on 2018/4/12.
//

#import <UIKit/UIKit.h>

@interface UIView (NFFrame)

@property (nonatomic, assign) CGFloat nf_x;
@property (nonatomic, assign) CGFloat nf_y;
@property (nonatomic, assign) CGFloat nf_width;
@property (nonatomic, assign) CGFloat nf_height;
@property (nonatomic, assign) CGPoint nf_origin;
@property (nonatomic, assign) CGSize nf_size;
@property (nonatomic, assign) CGFloat nf_bottom;
@property (nonatomic, assign) CGFloat nf_tail;
@property (nonatomic, assign) CGFloat nf_middleX;
@property (nonatomic, assign) CGFloat nf_middleY;

@end
 
